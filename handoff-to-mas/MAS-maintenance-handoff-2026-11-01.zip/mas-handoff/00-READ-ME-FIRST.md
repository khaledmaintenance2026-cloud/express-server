# حزمة تسليم قسم الصيانة: من «صيانتي» إلى MAS-APP

التاريخ: 2026-11-01 — أُعدّت لمساعد MAS ولصاحب المشروع (خالد الاغبري).
الغرض: يبدأ مساعد MAS بفهم قسم الصيانة وفحصه قبل نقل أي كود، كما طلب. لا يوجد في هذه الحزمة أي كلمة سر أو مفتاح (انظر القسم 10).

## 0. الإجابة عن الأسئلة الخمسة

| # | سؤال مساعد MAS | الإجابة | الحالة |
|---|---|---|---|
| 1 | مسار المشروع الآخر (تطبيق + سيرفر) وحق الاستخدام | التطبيق: مستودع GitHub عام `khaledmaintenance2026-cloud/sayanati-app` (فرع `main`، آخر تحديث وقت الإعداد `ba691d1`). السيرفر ليس على GitHub: نسخته في `sayanati-source/server/` هنا (ملفات الصيانة فقط). النسخة الحية: https://app.almas2.com/app/ | **حق الاستخدام يؤكده خالد بنفسه لمساعد MAS** — لا أستطيع الجزم به نيابة عنه |
| 2 | مكان الصيانة وحساب تجريبي | شاشة «الصيانة» في الرئيسية وما بداخلها (القسم 2). لا أضع حسابًا أو كلمة سر في ملف | الحساب التجريبي ينشئه خالد من التطبيق عند الحاجة، ويُرسَل خارج هذا الملف |
| 3 | ما الذي يُنقل | **افتراضي مقترح:** كل قسم الصيانة على ثلاث مراحل (القسم 8). المرحلة 1 النواة (أوامر العمل والفنيون والملاحظات والتقرير المطبوع والإشعارات). المرحلة 2 المخزون وطلبات القطع والعهدة والموردين ومواقع العمل. المرحلة 3 تحليل الصيانة والتقارير الآلية والربط بالإنتاج والسلامة | يعتمده خالد أو يغيّره |
| 4 | سير العمل المطلوب في MAS | سير العمل الحالي في صيانتي موثّق في القسم 4 كخط أساس. أسئلة MAS الخاصة في القسم 9 | **مطلوب من خالد** (قرارات MAS) |
| 5 | البيانات السابقة | **افتراضي مقترح:** MAS يبدأ ببيانات جديدة، وصيانتي يبقى يعمل ولا يُحذف منه شيء. يمكن لاحقًا تجهيز تصدير لمرة واحدة (أوامر العمل والفنيين والمخزون) إن طُلب | يقرره خالد |

افتراض أساسي: «نقل» هنا يعني **نسخ قسم الصيانة إلى MAS وتكييفه**، دون حذف أو تعطيل أي شيء في صيانتي الحي.

## 1. ما هو «قسم الصيانة» في صيانتي

| الوحدة | ما تفعله | شاشات Flutter (`lib/screens/maintenance/`) |
|---|---|---|
| أوامر العمل | ثلاثة أنواع: عطل طارئ، مهمة عامة (داخلية/خارجية)، صيانة وقائية. من الإنشاء حتى الإغلاق | `maintenance_dashboard_screen` (القائمة والتبويبات والأرقام)، `maintenance_new_report_screen` (بلاغ طارئ أو مهمة)، `maintenance_work_order_screen` (وقائي)، `maintenance_assign_screen` (تعيين فنيين)، `maintenance_edit_screen` (تعديل/حذف/إزالة فني)، `maintenance_task_close_screen` (إغلاق مع قطع الغيار) |
| ملاحظات المشرف | ملاحظات على أمر مُسنَد، تُرسَل لجروب الواتساب وللفني | `work_order_notes_sheet` |
| الفنيون | قائمة الفنيين وحالتهم (متاح، مشغول، إجازة) وتخصصاتهم | تُدار من تبويب في الإدارة (`admin/technicians_tab`، خارج الحزمة) |
| التقارير | تقرير بلاغ مطبوع، تقارير آلية (أسبوعي، شهري، سنوي)، تقرير بمدة مخصصة | `maintenance_report_print_screen`، `maintenance_completed_screen` (مركز التقارير)، `maintenance_reports_screen` |
| تحليل الصيانة | رسوم بيانية لأوامر العمل وأداء الفنيين | `maintenance_analysis_screen` |
| المخزون وطلبات القطع | كتالوج أصناف، طلب قطعة (تصميم ثم صرف ثم إرجاع)، حد أدنى وتنبيه | `inventory_dashboard_screen`، `inventory_screen`، `inventory_quick_movement_sheet` |
| سجل الحركة، الموردون، مواقع العمل | سجل موحّد بستة أنواع حركة، موردون، مواقع، تصدير CSV | `inventory_movements_screen`، `inventory_suppliers_screen`، `inventory_work_sites_screen` |
| العهدة | عدد ومعدات تُسلَّم لفني وتُسترجَع، مع تنبيه تأخير | داخل `inventory_screen` (تبويب «العهدة») |
| ربط الإنتاج | بلاغ عطل الإنتاج يظهر في قائمة الصيانة ويُحوَّل لأمر عمل؛ وباتش الإنتاج يُربط بأمر صيانة فتُحسب مدة التوقف تلقائيًا | داخل `maintenance_dashboard_screen` و`maintenance_edit_screen` |
| الإشعارات | واتساب لجروب الصيانة، إشعار داخل التطبيق، Push، وويب هوك | `services/notification_router.dart` (توجيه الضغط على الإشعار) |

ملف غير مستخدم: `maintenance_incoming_incidents_screen.dart` (وظيفته انتقلت للداشبورد). لا حاجة لنقله.

## 2. خريطة الملفات في الحزمة

```
00-READ-ME-FIRST.md                 هذا الملف
sayanati-source/
  flutter/
    pubspec.yaml                    الحزم المستعملة في كل التطبيق (لا كلها للصيانة)
    lib/screens/maintenance/        18 شاشة (الصيانة والمخزون)
    lib/models/                     maintenance_report, maintenance_analysis, technician,
                                    work_order_note, inventory, supplier, work_site, custody,
                                    production (Incident وBatch)، app_notification، batch_edit
    lib/services/                   api_client, auth_service (الأدوار)، constants, arabic_format,
                                    app_state (ملف الحالة الكامل 1814 سطرًا)،
                                    app_state_maintenance_excerpt (الأجزاء المتعلقة بالصيانة فقط)،
                                    maintenance_report_html (طباعة)، work_order_notes_service،
                                    notification_router، push_notification_service، html_report_opener*
    lib/widgets/common.dart, lib/theme/app_theme.dart
    lib/screens/home/section_tools.dart   كيف تظهر الصيانة وأدواتها في الرئيسية (خاص بصيانتي)
  server/
    schema.sql                      كل جداول النظام (27 جدولًا). جدول work_order_notes يُنشأ عند أول تشغيل من كود routes/workOrders.js
    server.js                       تركيب المسارات وتشغيل الجداول الزمنية
    routes/                         workOrders, technicians, inventory, custody, maintenanceAnalysis,
                                    dashboard, production (البلاغات وربط الباتش)، reports (CSV)، webhooks،
                                    users_technician_sync_excerpt (ربط المستخدم بسجل فني)
    services/                       maintenanceReport (HTML)، maintenanceReportScheduler، notifications،
                                    textmebot (واتساب)، push (FCM)، webhooks، inventoryMovements،
                                    batchWorkOrderLink، facilities
    middleware/auth.js              JWT والأدوار (المرجع الأهم للصلاحيات)
    migrate-*.js                    الترحيلات المتعلقة بالصيانة بالترتيب التاريخي
    lib/, config/                   إطار HTTP الصغير وعميل PostgreSQL الخاص بصيانتي (مرجع فقط)
```

ما لم يُرفق لأنه خارج الصيانة: تسجيل الدخول وإدارة المستخدمين، تصاريح السلامة وLOTO وإصابات العمل، الدردشة، العمل الإضافي، الإجازات، مراقبة المعمول، تكامل «راصد». ولم يُرفق أي ملف أسرار.

مهم: الملفات الأصلية حيّة وتعمل في الإنتاج الآن. لا تعدّلوا عليها، انسخوا منها.

## 3. الأدوار والصلاحيات (من السيرفر، وهو المرجع الملزم)

الأدوار المرتبطة بالصيانة: `admin` (يمر من كل قيد دور)، `maintenance_manager` (مسؤول الصيانة)، `maintenance_technician` (فني)، `inventory_manager` (مسؤول المخزون)، `designer` (مصمم). `safety` تنشئ بلاغ عطل طارئ فقط. `production` و`production_manager` ينشئان بلاغ عطل إنتاج (بلاغ وليس أمر عمل). في الكود ثلاث قوائم جاهزة: `MAINTENANCE_ROLES` (مسؤول + فني)، `TECHNICIAN_ROLES` (فني + مسؤول مخزون + مصمم، أي «أفراد الصيانة القابلون للتكليف»)، `INVENTORY_MANAGE_ROLES` (مسؤول صيانة + مسؤول مخزون).

| الإجراء | من يقدر |
|---|---|
| رؤية قائمة أوامر العمل | المسؤول والمدير: كل الأوامر. الفني والمخزون والمصمم: ما أُسنِد إليهم أو رفعوه بأنفسهم فقط. بقية الأدوار بلا قيد في الاستعلام |
| إنشاء بلاغ طارئ أو مهمة | مسؤول الصيانة، المدير، ومسؤول السلامة |
| إنشاء أمر وقائي، تحويل بلاغ إنتاج لأمر عمل | مسؤول الصيانة والمدير فقط |
| تعديل أمر، حذفه، إضافة/إزالة فني، كتابة ملاحظة مشرف، طلب تقرير مخصص | مسؤول الصيانة والمدير فقط |
| تغيير الحالة إلى «قيد التنفيذ» أو «بانتظار قطع» | الفني ومسؤول المخزون والمصمم على ما أُسنِد إليهم فقط، والمسؤول على أي أمر |
| إلغاء أمر أو إعادته للانتظار | مسؤول الصيانة والمدير فقط |
| إنجاز الأمر (إغلاق) | الفني المُسنَد له فعليًا (أو مسؤول المخزون/المصمم المُسنَد)، ومسؤول الصيانة والمدير على أي أمر |
| تحليل الصيانة | المسؤول، الفني، مسؤول المخزون، المصمم (قرار 2026-10-26؛ كان للمسؤول فقط) |
| المخزون: قراءة | مسؤول، فني، مسؤول مخزون، مصمم |
| المخزون: إضافة/تعديل صنف، صرف وإرجاع قطعة، حركة سريعة، موردون، مواقع | مسؤول الصيانة ومسؤول المخزون |
| طلب قطعة | مسؤول، فني، مسؤول مخزون (ليس المصمم) |
| رفع تصميم قطعة | المصمم ومسؤول الصيانة |
| العهدة: عرض | مسؤول، فني، مسؤول مخزون. تسليم/استرجاع/إدارة: مسؤول الصيانة ومسؤول المخزون |

قاعدة حاسمة في هذا المشروع: **القيد الملزم على السيرفر**؛ إخفاء الزر في التطبيق تحسين لتجربة الاستخدام فقط.

ربط الحساب بالفنيين: قائمة «تعيين فني» تقرأ من جدول `technicians` المنفصل عن `users`. عند اعتماد مستخدم أو تغيير دوره إلى أحد `TECHNICIAN_ROLES` يُنشأ له سجل في `technicians` أو يُربط بسجل قائم بنفس الاسم (انظر `server/routes/users_technician_sync_excerpt.js`). بدون هذا الربط لا يظهر الشخص في التعيين ولا يرى مهامه.

## 4. سير العمل الحالي (خط أساس)

**حالات أمر العمل** (`work_orders.status`): `new`، `pending_assignment` (بانتظار التعيين)، `waiting_loto`، `in_progress`، `waiting_parts`، `completed`، `cancelled`. في التطبيق تُعرض مختصرة إلى ثلاث: بانتظار التعيين، قيد التنفيذ، مكتمل.

**الأنواع:** `kind` = `emergency` أو `preventive`. «المهمة العامة» هي أمر `emergency` مع `is_task = true` و`task_scope` = `internal` أو `external`، لتظهر في تبويب منفصل بدون كود جديد.

1. **الإنشاء.** يرفع مسؤول الصيانة (أو السلامة) بلاغًا طارئًا مباشرة، أو يحوّل بلاغ عطل الإنتاج إلى أمر عمل بزر «تحويل». الحماية من التكرار: تحويل البلاغ نفسه مرتين يعيد الأمر الأول، وإنشاء مباشر متطابق خلال دقيقتين يعيد الأول (قفل لكل مفتاح). حدث ذلك فعلًا في الإنتاج وسبّب رسائل مكررة، فلا تحذفوا هذه الحماية عند النقل.
2. **التعيين.** يسند المسؤول فنيًا أو أكثر (جدول `work_order_technicians`)، ويكتب ملاحظة مشرف اختيارية تُدمج في رسالة التعيين. لا يُقبل تعيين فني حالته غير «متاح» (إلا لو كان مُسنَدًا لنفس الأمر). الفني المُسنَد يصير «مشغول». يسجَّل أيضًا من أسند (`assigned_by`) ويظهر على بطاقة المهمة.
3. **التنفيذ.** الفني يحدّث الحالة إلى «قيد التنفيذ» أو «بانتظار قطع»، ويقدر طلب قطعة من شاشة الإغلاق مربوطة بالأمر.
4. **الإغلاق.** الفني يكتب وصف العمل المنجز وملاحظات اختيارية وقطع الغيار المستخدمة (`spare_parts_used`) فيصير الأمر `completed`، ويعود الفنيون «متاحين». إلغاء الأمر أو حذفه يحرر الفنيين بنفس الطريقة (كان خللًا قديمًا يترك فنيين «مشغولين» للأبد، وأُصلح، وأُضيف سكربت إصلاح `migrate-technician-status-reconcile.js`).
5. **الربط بالإنتاج.** يمكن ربط باتش إنتاج بأمر صيانة (يدويًا، أو تلقائيًا بـ«رقم الباتش المتوقع» الذي يُكتب عند رفع بلاغ الإنتاج)، فتُحسب مدة وسبب التوقف في الباتش من الأمر وتتحدّث عند إنجازه (`services/batchWorkOrderLink.js`).
6. **الربط بالسلامة.** `requires_loto` وحالة `waiting_loto`، وإمكانية ربط تصريح عمل بأمر قائم (من قسم السلامة). هذا الربط يعتمد على جداول السلامة غير المرفقة.

**طلب قطعة:** `pending_design` (إن احتاج تصميمًا) ← `pending_issue` ← `issued` ← `returned` (اختياري). الرصيد لا يتغيّر إلا عند «الصرف» و«الإرجاع» الفعليين بيد مسؤول المخزون/الصيانة. كل حركة تُسجَّل في `inventory_movements` (ستة أنواع: توريد، صرف استهلاكي، صرف معدات، إعادة معدات، تسوية جرد، تعديل مخزون).

**التقارير الآلية** (`services/maintenanceReportScheduler.js`): فحص كل ساعة. أسبوعي كل 7 أيام تقريبًا، سنوي كل 365 يومًا تقريبًا، وشهري يوم 25 الساعة 8 صباحًا بتوقيت الرياض عن دورة 25 ← 24 (عُدّل 2026-10-26؛ يحتاج إعادة تشغيل خدمة السيرفر في الإنتاج ليسري). تُرسَل لجروب «الصيانة» برابط تقرير HTML. التقرير الأساسي أبيض وأسود عمدًا ليُطبع بوضوح.

## 5. نموذج البيانات (PostgreSQL)

الجداول الأساسية للصيانة (التفاصيل الكاملة في `schema.sql`):

| الجدول | أهم الأعمدة والعلاقات |
|---|---|
| `work_orders` | `kind`, `status`, `description`, `equipment_id`/`equipment_name`/`equipment_code`, `line_id`, `facility`, `incident_report_id` (من بلاغ إنتاج)، `assigned_technician_id` (قديم) و`assigned_by`/`assigned_by_user`, `requires_loto`, `created_by`/`created_by_user`, أوقات (`created_at`, `assigned_at`, `started_at`, `completed_at`), `close_description`, `close_notes`, `is_task`, `task_scope`, `expected_batch_number`, `reminder_interval_days` |
| `work_order_technicians` | (`work_order_id`, `technician_id`) مفتاح مركّب. هو المصدر الصحيح للفنيين المتعددين |
| `technicians` | `name`, `phone`, `specialty` (نص حر قد يحوي أكثر من تخصص)، `status` (available/busy/on_leave)، `user_id` يربط بحساب المستخدم |
| `work_order_notes` | ملاحظات المشرف: `note`, `author_name`, `author_user`, `work_order_status`. يُنشأ تلقائيًا من الكود |
| `spare_parts_used` | قطع الغيار عند الإغلاق: `part_name`, `quantity`, `unit_cost` |
| `incident_reports` | بلاغ عطل الإنتاج: `line_id`, `equipment_id`, `downtime_started_at`/`downtime_ended_at`, `status` (open/linked/closed)، `photo_path`، `expected_batch_number` |
| `equipment`, `production_lines` | المعدات والخطوط (`facility`: مصنع الرجال، مصنع النساء، المستودع العام) |
| `inventory_items` | `name`, `category`, `unit`, `quantity`, `min_quantity`, `supplier_id`, `site_id` |
| `part_requests` | الحالة (4 قيم)، `item_id`, `quantity`, `work_order_id`, `technician_id`, `needs_design`, حقول التصميم والصرف والإرجاع (من ومتى) |
| `inventory_movements` | `type` (6 قيم)، `source` (inventory/custody)، `quantity_delta`/`quantity_after` (فارغة لحركات العهدة)، `part_request_id` |
| `suppliers`, `work_sites` | موردون ومواقع عمل (نشط/غير نشط) |
| `custody_items`, `custody_assignments` | العهدة. فهرس فريد يمنع تسليم عدة واحدة لشخصين معًا |
| `notifications` | إشعار داخل التطبيق لكل مستخدم: `title`, `body`, `event_type`, `ref_id`, `is_read` |
| `site_settings` | إعدادات مفتاح/قيمة (القسم 7) |
| `webhooks` | ويب هوك خارجي للأحداث |
| `device_tokens` | رموز Push للأجهزة. ليس في `schema.sql`؛ يُنشأ بترحيل منفصل `migrate-device-tokens.js` (غير مرفق، خارج الصيانة) |

مرتبطة بجدول `users` (الأدوار: `admin`, `maintenance_technician`, `maintenance_manager`, `production`, `production_manager`, `safety`, `general`, `inventory_manager`, `designer`, `contractor`، وقيد المصنع `production_facility`).

ملاحظة: `schema.sql` تراكمي ويضيف أعمدة وقيودًا بالترتيب. إن أراد مساعد MAS البنية الدقيقة للقاعدة الحية فيمكن لخالد تشغيل `pg_dump -s` لتصدير الهيكل فقط (اختياري).

## 6. واجهة API (البادئة `/api`، المصادقة بـ`Authorization: Bearer <JWT>`)

| المسار | الطرق (والأدوار) |
|---|---|
| `/work-orders` | `GET /` (قائمة، مفلترة بالدور)، `GET /:id` (تفاصيل مع قطع الغيار وLOTO)، `POST /` (إنشاء)، `PATCH /:id` (تعديل)، `DELETE /:id`، `PATCH /:id/assign` (تعيين فنيين)، `GET /:id/technicians`، `DELETE /:id/technicians/:techId`، `PATCH /:id/status`، `PATCH /:id/close`، `GET/POST /:id/notes`، `POST /reports/request` (تقرير مخصص) |
| `/technicians` | `GET /`، `POST /`، `PATCH /:id`، `DELETE /:id`، `GET /:id/performance` |
| `/inventory` | `items` (CRUD)، `items/categories`، `items/:id/movement` (حركة سريعة)، `suppliers` (CRUD)، `sites` (CRUD)، `part-requests` (إنشاء، `/design`، `/issue`، `/return`، حذف)، `movements`، `export.csv` (بمعامل `type` = `items` أو `movements`) |
| `/custody` | `items` (CRUD)، `assignments` (عرض، تسليم، `/:id/return`) |
| `/maintenance-analysis` | `GET /?from=&to=` |
| `/dashboard` | `GET /` (أرقام الداشبورد السريعة، تُقسَّم بحسب دور المستخدم) |
| `/production/incidents` | بلاغات عطل الإنتاج (إنشاء، إنهاء التوقف، حذف). التحويل لأمر عمل يتم عبر `POST /work-orders` مع `incidentReportId` |
| `/reports` | تصدير CSV بحسب القسم |
| `/webhooks` | إدارة ويب هوك الأحداث |

أحداث الويب هوك والإشعارات المتعلقة بالصيانة: `work_order_created`, `work_order_assigned`, `work_order_updated`, `work_order_deleted`, `work_order_technician_removed`, `work_order_note_added`, `work_order_completed`, `part_request_created`, `part_request_designed`, `part_request_issued`, `part_request_returned`, `custody_assigned`, `custody_returned`, `incident_created`, `maintenance_report_weekly|monthly|yearly|custom`.

## 7. التكاملات والإعدادات الخارجية

- **واتساب:** عبر خدمة TextMeBot (بوابة غير رسمية). المفتاح ومعرّفات الجروبات مخزنة في `site_settings` (مفاتيح بأسماء `textmebot_api_key` و`textmebot_group_maintenance` و`textmebot_group_production_men|women` و`textmebot_group_safety`)، وليست في الكود. خالد يرغب بالانتقال لاحقًا إلى واجهة واتساب الرسمية من Meta، فاعزلوا الإرسال خلف دالة واحدة (`sendWhatsappText`).
- **Push:** Firebase Cloud Messaging عبر حساب خدمة على السيرفر (`services/push.js`)، والتطبيق يسجّل رمز الجهاز.
- **إعدادات أخرى** في `site_settings`: `public_base_url` (لبناء رابط التقرير)، `factory_name`، `report_footer`.
- **روابط التقارير:** السيرفر يولّد ملف HTML في `public/uploads/reports/` ويعطي رابطًا مطلقًا مبنيًا من `public_base_url`، والتطبيق يفتحه عبر `html_report_opener`. بدون `public_base_url` يفشل إنشاء التقرير.
- **التخزين:** ملفات على قرص السيرفر نفسه (ليست في قاعدة البيانات): صور بلاغات الإنتاج في `public/uploads/incidents/`، وملفات تصميم القطع في `public/uploads/part-designs/`. أي نقل للبيانات القديمة يشمل هذه المجلدات أيضًا.

## 8. مقاربتان للدمج (قرار لمساعد MAS بعد فحص MAS)

لم أفحص كود MAS. كل ما أعرفه عنه من صورة صفحة مستودعه: تطبيق Flutter كبير، ويظهر فيه Firebase (مجلد `third_party/firebase_database_web`)، ومجلد `postman`، ومجلد `docs`.

- **المقاربة أ — واجهة في MAS فوق خلفية صيانتي الحالية.** تُنقل شاشات Flutter فقط، وتبقى بيانات الصيانة على سيرفر صيانتي (PostgreSQL). الأسرع والأقل مخاطرة، ولا ترحيل بيانات. تحتاج جسر مصادقة بين مستخدمي MAS ومستخدمي صيانتي (الأدوار والفنيون)، وتبقي نظامين.
- **المقاربة ب — نقل كامل إلى خلفية MAS.** يُعاد تنفيذ المسارات والجداول (القسم 5 و6) بتقنية MAS. أنظف على المدى الطويل وتمنع تكرار المستخدمين والصلاحيات، لكنها أكبر عملًا وأعلى مخاطرة، وتحتاج خطة ترحيل بيانات وتشغيل متوازٍ.

التوصية: ابدؤوا بتعريف MAS (المستخدمون والأدوار والفروع والمرفقات والإشعارات وطريقة الـAPI)، ثم اختاروا. وفي الحالتين اتبعوا المراحل الثلاث (القسم 0، السؤال 3).

## 9. أسئلة تحتاج قرار خالد (سير العمل في MAS)

1. من ينشئ بلاغ العطل في MAS؟ (كل الموظفين، أم أقسام معينة، أم المشرفون فقط)
2. من يسند الفني؟ ومن يعتمد الإغلاق؟ (في صيانتي: المسؤول يسند، والفني ينجز دون اعتماد إضافي)
3. هل يُربط البلاغ بفرع أو جهاز أو أصل في MAS؟ (في صيانتي: موقع نصي + معدة + مصنع من ثلاثة)
4. هل يوجد في MAS أصلًا مفهوم «بلاغ» أو «طلب» أو «أصل» أو «مخزون» يجب الاندماج معه بدل إنشاء نسخة ثانية؟
5. هل يبقى الواتساب هو قناة الإشعار الرئيسية في MAS، أم الإشعار داخل التطبيق فقط؟
6. من يدخل شاشات الصيانة في MAS؟ (يُقترح تحويل أدوار MAS الموجودة إلى الأدوار الخمسة في القسم 3 بدل أدوار جديدة)

## 10. تحذيرات ونقاط انتباه عند النقل

- **لا تنسخوا الأسرار.** لم تُرفق: ملف `.env`، حساب خدمة Firebase، مفتاح TextMeBot، `JWT_SECRET`، كلمات سر قاعدة البيانات. يُنشأ كل ذلك من جديد لـMAS (يوجد `server/env.example.txt` بصيغة القيم فقط).
- `AppState` (ملف الحالة) متضخم: 1814 سطرًا فيه الصيانة والإنتاج والسلامة وغيرها معًا. لا تنسخوه كما هو. استخدموا `app_state_maintenance_excerpt.dart` كمرجع واستخرجوا منه مزوّد حالة خاص بالصيانة.
- الشاشات تستورد `app_state.dart` و`auth_service.dart` و`common.dart` و`app_theme.dart`. هذه تعتمد على بنية صيانتي (Provider، `AppRole`، ألوانها). تحتاج تكييفًا مع ما في MAS لا نسخًا حرفيًا.
- الكود يعتمد على: Flutter مع Provider، واجهة عربية RTL بالكامل، وتنسيق أرقام عربية (`arabic_format.dart`). لا توجد حزمة رسوم بيانية خارجية: الرسوم مرسومة بـContainer عمدًا.
- سيرفر صيانتي مكتوب بإطار HTTP صغير خاص وعميل PostgreSQL خاص (مجلد `lib/` ونمط `Router` و`pool.query`) وليس Express. المسارات قابلة للقراءة والترجمة، لكنها ليست مباشرة الصلاحية لأي إطار آخر.
- لا يوجد اختبار آلي للسيرفر ضمن الحزمة. التحقق كان اختبارات مخصصة على قاعدة PostgreSQL مع محاكاة. يُنصح بكتابة اختبارات للصلاحيات (القسم 3) عند إعادة التنفيذ.
- شاشة لوحة الصيانة تفتح `safety_permit_request_screen` (طلب تصريح عمل مرتبط بأمر). هذه من قسم السلامة وغير مرفقة. إما تُربط بتصاريح MAS أو يُحذف الزر مؤقتًا.
- تغييرات اليوم 2026-10-26 على السيرفر (صلاحية تحليل الصيانة، والتقرير الشهري يوم 25) موجودة في ملفات هذه الحزمة. وقد تحتاج إعادة تشغيل خدمة صيانتي حتى تظهر في الإنتاج.
- في نسخة `server/services/textmebot.js` داخل الحزمة استُبدلت أرقام جوال ظهرت كأمثلة في التعليقات بأرقام وهمية (`0500000000`)، حفاظًا على الخصوصية. لا أثر لذلك على المنطق، والملف الأصلي على سيرفر صيانتي لم يُمسّ.
