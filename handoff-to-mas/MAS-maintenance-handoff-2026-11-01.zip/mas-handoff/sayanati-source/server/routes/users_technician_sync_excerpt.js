// مقتطف مرجعي من routes/users.js (الأسطر 60–115 من الأصل): كيف يُربَط حساب مستخدم بسجل في جدول الفنيين (technicians)
// حتى يظهر في قائمة «تعيين فني». يُستدعى عند اعتماد المستخدم أو تغيير دوره لأحد TECHNICIAN_ROLES.
// الملف الكامل routes/users.js خارج نطاق الصيانة (إدارة المستخدمين) فلم يُرفق.
const SAFETY_FACILITIES = ['مصنع الرجال', 'مصنع النساء', 'المستودع العام'];

// الأدوار الصحيحة القابلة للاختيار عند الاعتماد أو تغيير الدور — دور
// "الصيانة" العام انقسم إلى فني صيانة ومسؤول صيانة، وأُضيف لاحقًا دور
// "مسؤول إنتاج" (production_manager) يملك كل صلاحيات "إنتاج" العادي بالإضافة
// لصلاحية تعديل/حذف باتشات قديمة (راجع schema.sql وmiddleware/auth.js).
// "مسؤول المخزون" (inventory_manager) و"مصمم" (designer): دوران جديدان لقسم
// "المخزون والقطع" بالصيانة (راجع routes/inventory.js). بقرار من الإدارة
// (2026-10-03) أصبح الاثنان أيضًا يُعتبران أفراد صيانة قابلين للتكليف —
// راجع TECHNICIAN_ROLES في middleware/auth.js وensureTechnicianForUser تحت.
const VALID_ROLES = ['admin', 'maintenance_technician', 'maintenance_manager', 'production', 'production_manager', 'safety', 'contractor', 'general', 'inventory_manager', 'designer'];

// عند اعتماد مستخدم بدور "فني صيانة" (maintenance_technician) لأول مرة، أو
// تغيير دور مستخدم موجود لهذا الدور لاحقًا، يجب أن يظهر رسميًا في جدول
// الفنيين (technicians) — وإلا يبقى بإمكانه الدخول للنظام والعمل كفني، لكن
// لا يظهر اسمه إطلاقًا في قائمة "تعيين فني" عند توزيع البلاغات (تلك القائمة
// تُقرأ من جدول technicians المنفصل تمامًا عن جدول users، ولم يكن هناك أي
// ربط تلقائي بينهما من قبل). منذ 2026-10-03 نفس الربط يحدث أيضًا لمسؤول
// المخزون (inventory_manager) والمصمم (designer) — راجع TECHNICIAN_ROLES
// في middleware/auth.js واستخدامها تحت.
//
// نحاول أولًا الربط باسم فني مُضاف يدويًا من قبل (بلا حساب مستخدم مرتبط
// بعد، user_id فارغ) بنفس الاسم تمامًا — يغطي حالة الفنيين الموجودين أصلًا
// في القائمة (مثل من أُضيفوا يدويًا قبل هذا التحديث) الذين ينشئون حسابًا
// الآن لأول مرة، فلا نكرر اسمه بسجل جديد منفصل. فإن لم يوجد تطابق، ننشئ
// سجل فني جديدًا ونربطه بحساب المستخدم مباشرة. لو كان مرتبطًا بالفعل
// (user_id يشير له سلفًا) لا نفعل شيئًا لتفادي التكرار عند اعتماد/تغيير
// دور نفس المستخدم أكثر من مرة.
//
// التخصص (specialty) في السجل الجديد عرض فقط (لا يؤثر على أي صلاحية) —
// نضعه مناسبًا لدور المستخدم فقط لتسهيل التمييز بينهم في قائمة "تعيين فني".
function specialtyForRole(role) {
  if (role === 'inventory_manager') return 'مخزون';
  if (role === 'designer') return 'تصميم';
  return 'عام';
}

async function ensureTechnicianForUser(user) {
  const linked = await pool.query('SELECT id FROM technicians WHERE user_id = $1', [user.id]);
  if (linked.rows.length > 0) return;

  const byName = await pool.query(
    'SELECT id FROM technicians WHERE user_id IS NULL AND trim(name) = trim($1) LIMIT 1',
    [user.name]
  );
  if (byName.rows.length > 0) {
    await pool.query('UPDATE technicians SET user_id = $1, updated_at = now() WHERE id = $2', [user.id, byName.rows[0].id]);
    return;
  }

  await pool.query(
    'INSERT INTO technicians (name, phone, specialty, user_id) VALUES ($1, $2, $3, $4)',
    [user.name, user.phone || null, specialtyForRole(user.role), user.id]
  );
}

